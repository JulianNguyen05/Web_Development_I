﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BaiTap1_65133958.Models
{
    public class CalModels
    {
        public double a { get; set; }
        public double b { get; set; }
        public string pt { get; set; }
    }


}