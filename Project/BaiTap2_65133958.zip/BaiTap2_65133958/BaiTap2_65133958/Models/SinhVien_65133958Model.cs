﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BaiTap2_65133958.Models
{
    public class SinhVien_65133958Model
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public float Marks { get; set; }
    }
}